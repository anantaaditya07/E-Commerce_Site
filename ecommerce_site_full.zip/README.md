﻿# MyStore - Modern E-commerce Template
This is a static front-end e-commerce template created for internship submission.
